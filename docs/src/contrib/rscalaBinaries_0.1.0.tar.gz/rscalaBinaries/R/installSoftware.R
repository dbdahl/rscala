installSoftware <- function(urls, installPath, software, version, os, arch, verbose=FALSE, downloadFailureCount=0, extractFailureCount=0) {
  dir.create(installPath, showWarnings=FALSE, recursive=TRUE)
  sel <- urls$software == software
  if ( missing(version) ) {
    version <- if ( software == "java" ) {
      if ( Sys.getenv("RSCALA_JAVA_VERSION","") != "" )  Sys.getenv("RSCALA_JAVA_VERSION","") else "8"
    } else if ( software == "scala" ) {
      if ( Sys.getenv("RSCALA_SCALA_VERSION","") != "" ) Sys.getenv("RSCALA_SCALA_VERSION","") else "2.12"
    } else if ( software == "sbt" ) {
      if ( Sys.getenv("RSCALA_SBT_VERSION","") != "" ) Sys.getenv("RSCALA_SBT_VERSION","") else "1.2"
    } else NULL
  }
  sel <- sel & (urls$version == version)
  if ( missing(os) ) {
    os <-  if ( software == "java" ) osType() else "any"
  }
  sel <- sel & (urls$os == os)
  if ( missing(arch) ) {
    arch <- if ( software == "java" ) {
      if ( Sys.getenv("RSCALA_JAVA_ARCH","") != "" ) Sys.getenv("RSCALA_JAVA_ARCH","") else R.Version()$arch
    } else "any"
  }
  sel <- if ( arch == "any" ) sel else {
    sel & sapply(urls$arch, function(re) grepl(re,arch))
  }
  urls2 <- urls[sel, ]
  candidates <- urls2[order(as.numeric(urls2$priority),decreasing=TRUE),"url"]
  if ( verbose ) {
    len <- length(candidates)
    if ( len == 1 ) cat(paste0("There is 1 candidate.\n\n"))
    else cat(paste0("There are ",len," candidates.\n\n"))
  }
  if ( missing(downloadFailureCount) && ( Sys.getenv("RSCALA_DOWNLOAD_FAILURE_COUNT","") != "" ) ) downloadFailureCount <- as.integer(Sys.getenv("RSCALA_DOWNLOAD_FAILURE_COUNT",""))
  if ( missing(extractFailureCount)  && ( Sys.getenv("RSCALA_EXTRACT_FAILURE_COUNT", "") != "" ) ) extractFailureCount  <- as.integer(Sys.getenv("RSCALA_EXTRACT_FAILURE_COUNT", ""))
  dfc <- efc <- 0
  for ( candidate in candidates ) {
    cat(paste0("Trying: ",candidate,"\n"))
    archivePath <- file.path(tempdir(), basename(candidate))
    result <- try(download.file(candidate, archivePath), silent=TRUE)
    if ( inherits(result,"try-error") || ( result != 0 ) || ( dfc < downloadFailureCount ) ) {
      dfc <- dfc + 1
      next
    }
    finalPath <- try(extractArchive(archivePath, installPath, software), silent=TRUE)
    unlink(archivePath,FALSE,TRUE)
    if ( inherits(finalPath,"try-error") || ( efc < extractFailureCount ) ) {
      efc <- efc + 1
      next
    }
    break
  }
}
