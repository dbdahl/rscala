extractArchive <- function(archivePath, parentDirectory, directoryName) {
  tmpInstallDirectory <- file.path(parentDirectory, paste0("tmp-", directoryName))
  if ( file.exists(tmpInstallDirectory) ) unlink(tmpInstallDirectory, TRUE, TRUE)
  dir.create(tmpInstallDirectory, showWarnings=FALSE)
  if ( endsWith(archivePath,".zip") ) utils::unzip(archivePath, exdir=tmpInstallDirectory, unzip="internal")
  else if ( endsWith(archivePath,".tar.gz") || endsWith(archivePath,".tgz") ) utils::untar(archivePath, exdir=tmpInstallDirectory, tar="internal")
  else stop(paste0("Unrecognized file type for ", archivePath))
  home <- list.files(tmpInstallDirectory, full.names=TRUE)
  if ( length(home) != 1 ) stop(paste0("Expected only one directory in ",tmpInstallDirectory))
  finalPath <- file.path(parentDirectory, directoryName)
  if ( file.exists(finalPath) ) unlink(finalPath, TRUE, TRUE)
  homeOnMac <- file.path(home,"Contents","Home")
  if ( file.exists(homeOnMac) ) home <- homeOnMac
  status <- file.rename(home, finalPath)
  if ( ! status ) stop(paste0("Problem renaming ", home, " to ", finalPath))
  unlink(tmpInstallDirectory, TRUE, TRUE)
  finalPath
}
