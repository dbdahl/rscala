local({
  pkgPath <- Sys.getenv("R_PACKAGE_DIR")
  installPath <- file.path(pkgPath, "binaries")
  what <- Sys.getenv("RSCALA_INSTALL", "java,scala")
  components <- strsplit(what, "\\s*,\\s*")[[1]]
  for ( software in components ) installSoftware(installPath, software)
})
