local({
  load(file.path("R","sysdata.rda"))
  installPath <- file.path(Sys.getenv("R_PACKAGE_DIR"),"binaries")
  components <- strsplit(Sys.getenv("RSCALA_INSTALL","java,scala"),"\\s*,\\s*")[[1]]
  for ( software in components ) installSoftware(urls,installPath,software)
})
