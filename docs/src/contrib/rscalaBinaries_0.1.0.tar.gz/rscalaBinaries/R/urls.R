urls <- read.table(header=TRUE, colClasses="character", text="
software  os                   arch     version  priority  url
    java  windows  ^(x86|i[3-6]86)$          11        70  https://github.com/AdoptOpenJDK/openjdk11-binaries/releases/download/jdk-11.0.3%2B7/OpenJDK11U-jre_x86-32_windows_hotspot_11.0.3_7.zip
    java  windows      ^x86(-|_)64$          11        70  https://github.com/AdoptOpenJDK/openjdk11-binaries/releases/download/jdk-11.0.3%2B7/OpenJDK11U-jre_x64_windows_hotspot_11.0.3_7.zip
    java  mac          ^x86(-|_)64$          11        70  https://github.com/AdoptOpenJDK/openjdk11-binaries/releases/download/jdk-11.0.3%2B7/OpenJDK11U-jre_x64_mac_hotspot_11.0.3_7.tar.gz
    java  linux        ^x86(-|_)64$          11        70  https://github.com/AdoptOpenJDK/openjdk11-binaries/releases/download/jdk-11.0.3%2B7/OpenJDK11U-jre_x64_linux_hotspot_11.0.3_7.tar.gz
    java  windows  ^(x86|i[3-6]86)$           8        70  https://github.com/AdoptOpenJDK/openjdk8-binaries/releases/download/jdk8u212-b03/OpenJDK8U-jre_x86-32_windows_hotspot_8u212b03.zip
    java  windows      ^x86(-|_)64$           8        70  https://github.com/AdoptOpenJDK/openjdk8-binaries/releases/download/jdk8u212-b03/OpenJDK8U-jre_x64_windows_hotspot_8u212b03.zip
    java  mac          ^x86(-|_)64$           8        70  https://github.com/AdoptOpenJDK/openjdk8-binaries/releases/download/jdk8u212-b03/OpenJDK8U-jre_x64_mac_hotspot_8u212b03.tar.gz
    java  linux        ^x86(-|_)64$           8        70  https://github.com/AdoptOpenJDK/openjdk8-binaries/releases/download/jdk8u212-b03/OpenJDK8U-jre_x64_linux_hotspot_8u212b03.tar.gz
    java  windows      ^x86(-|_)64$          11        50  https://cdn.azul.com/zulu/bin/zulu11.31.11-ca-jre11.0.3-win_x64.zip
    java  mac          ^x86(-|_)64$          11        50  https://cdn.azul.com/zulu/bin/zulu11.31.11-ca-jre11.0.3-macosx_x64.zip
    java  linux        ^x86(-|_)64$          11        50  https://cdn.azul.com/zulu/bin/zulu11.31.11-ca-jre11.0.3-linux_x64.tar.gz
    java  windows  ^(x86|i[3-6]86)$           8        50  https://cdn.azul.com/zulu/bin/zulu8.38.0.13-ca-jre8.0.212-win_i686.zip
    java  windows      ^x86(-|_)64$           8        50  https://cdn.azul.com/zulu/bin/zulu8.38.0.13-ca-jre8.0.212-win_x64.zip
    java  mac          ^x86(-|_)64$           8        50  https://cdn.azul.com/zulu/bin/zulu8.38.0.13-ca-jre8.0.212-macosx_x64.zip
    java  linux        ^x86(-|_)64$           8        50  https://cdn.azul.com/zulu/bin/zulu8.38.0.13-ca-jre8.0.212-linux_x64.tar.gz
    java  linux    ^(x86|i[3-6]86)$           8        50  https://cdn.azul.com/zulu/bin/zulu8.38.0.13-ca-jre8.0.212-linux_i686.tar.gz
    java  windows      ^x86(-|_)64$          11        30  https://d3pxv6yz143wms.cloudfront.net/11.0.3.7.1/amazon-corretto-11.0.3.7.1-windows-x64.zip
    java  mac          ^x86(-|_)64$          11        30  https://d3pxv6yz143wms.cloudfront.net/11.0.3.7.1/amazon-corretto-11.0.3.7.1-macosx-x64.tar.gz
    java  linux        ^x86(-|_)64$          11        30  https://d3pxv6yz143wms.cloudfront.net/11.0.3.7.1/amazon-corretto-11.0.3.7.1-linux-x64.tar.gz
    java  windows  ^(x86|i[3-6]86)$           8        30  https://d3pxv6yz143wms.cloudfront.net/8.212.04.2/amazon-corretto-8.212.04.2-windows-x86-jre.zip
    java  windows      ^x86(-|_)64$           8        30  https://d3pxv6yz143wms.cloudfront.net/8.212.04.2/amazon-corretto-8.212.04.2-windows-x64-jre.zip
    java  mac          ^x86(-|_)64$           8        30  https://d3pxv6yz143wms.cloudfront.net/8.212.04.2/amazon-corretto-8.212.04.2-macosx-x64.tar.gz
    java  linux        ^x86(-|_)64$           8        30  https://d3pxv6yz143wms.cloudfront.net/8.212.04.2/amazon-corretto-8.212.04.2-linux-x64.tar.gz
   scala  any                   any        2.11        50  https://downloads.lightbend.com/scala/2.11.12/scala-2.11.12.tgz
   scala  any                   any        2.11        20  https://byu.box.com/shared/static/kh0pew26qbai9mznyp6jvq3ve8g8gwuh.tgz
   scala  any                   any        2.12        50  https://downloads.lightbend.com/scala/2.12.8/scala-2.12.8.tgz
   scala  any                   any        2.12        20  https://byu.box.com/shared/static/d0s7imb7s572o3weezb0w1in4phcrp1u.tgz
   scala  any                   any        2.13        50  https://downloads.lightbend.com/scala/2.13.0/scala-2.13.0.tgz
   scala  any                   any        2.13        20  https://byu.box.com/shared/static/9vwwj0tge7kl6a39o29dpfs4dh0bxro7.tgz
     sbt  any                   any         1.2        50  https://piccolo.link/sbt-1.2.8.tgz
     sbt  any                   any         1.2        20  https://byu.box.com/shared/static/bgut2govob4dvzn8b9bkbrbd1r0lrnjx.tgz
")

