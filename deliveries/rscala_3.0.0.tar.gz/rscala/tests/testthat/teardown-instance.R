cat("Stopping instance. **************************\n")
close(s)
close(s2)