close(s)
close(s2)
cat("Stopping instance. **************************\n")
