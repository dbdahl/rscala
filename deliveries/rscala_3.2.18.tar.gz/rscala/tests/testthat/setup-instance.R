cat("Starting instance. ********************************\n")
s  <- scala(serialize.output=TRUE)
s2 <- scala(serialize.output=FALSE)
