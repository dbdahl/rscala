RTYPE_INT <- integer()
RTYPE_DOUBLE <- double()
RTYPE_LOGICAL <- logical()
RTYPE_RAW <- raw()
