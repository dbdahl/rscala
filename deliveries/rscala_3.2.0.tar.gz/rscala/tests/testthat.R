library(testthat)
library(rscala)

test_check("rscala")
