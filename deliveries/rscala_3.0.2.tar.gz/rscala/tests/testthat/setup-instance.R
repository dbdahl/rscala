cat("Starting instance. ********************************\n")
scala(serialize.output=TRUE)
scala(assign.name="s2",serialize.output=FALSE)