typeMap <- list()
typeMap[[INTEGER]] <- "integer"
typeMap[[DOUBLE]] <- "double"
typeMap[[BOOLEAN]] <- "integer"
typeMap[[STRING]] <- "character"
typeMap[[BYTE]] <- "raw"
