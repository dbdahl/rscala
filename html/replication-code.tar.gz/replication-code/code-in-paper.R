## ----setup,include=FALSE-------------------------------------------------
library('knitr')
opts_chunk$set(fig.path='figure/latex-', cache.path='cache/latex-', cache=TRUE, size="small", out.columns=84)
hook_output = knit_hooks$get('output')
knit_hooks$set(output = function(x, options) {
  if (!is.null(n <- options$out.lines)) {
    x = unlist(stringr::str_split(x, '\n'))
    if (length(x) > n) {
      # truncate the output
      x = c(head(x, n), '....\n')
    }
    x = paste(x, collapse = '\n') # paste first n lines together
  }
  if (!is.null(n <- options$out.columns)) {
    x = unlist(stringr::str_split(x, '\n'))
    probs <- nchar(x)>options$out.columns
    x[probs] <- paste(substr(x[probs],1,options$out.columns-3), '...', sep="")
    x = paste(x, collapse = '\n') # paste first n lines together
  }
  hook_output(x, options)
})

## ----installPackage,eval=FALSE-------------------------------------------
## install.packages('rscala')

## ----installScala,eval=FALSE---------------------------------------------
## rscala::scalaInstall()

## ----scalaInfo,eval=FALSE------------------------------------------------
## rscala::scalaInfo(verbose=TRUE)

## ----library-------------------------------------------------------------
library('rscala')

## ----instantiateInterpreter----------------------------------------------
s <- scalaInterpreter()

## ----quoteWhenNecessary, out.lines=16------------------------------------
h <- s$do('List')$'apply[Int]'(1L, 2L, 3L)
g <- h$":+"(100L)
g$toString()

## ----scalap, out.lines=14------------------------------------------------
scalap(s, 'scala.util.Random')

## ----bellUsingScala------------------------------------------------------
bell.using.rscala <- s$def('n: Int', '
  def snsk(n: Int, k: Int): BigInt = {
    if ( n == 0 && k == 0 ) BigInt(1)
    else if ( n == 0 || k == 0 ) BigInt(0)
    else k * snsk(n - 1, k) + snsk(n - 1, k - 1)
  }
  var sum = BigInt(0)
  for ( k <- 0 to n ) sum = sum + snsk(n, k)
  sum.doubleValue
')

## ----callBellUsingScala--------------------------------------------------
bell.using.rscala(10)

## ----bellArgs------------------------------------------------------------
args(bell.using.rscala)

## ----bellUsingR----------------------------------------------------------
bell.using.R <- function(n) {
  snsk <- function(n, k) {
    if ( n == 0 && k == 0 ) 1
    else if ( n == 0 || k == 0 ) 0
    else k * snsk(n - 1, k) + snsk(n - 1, k - 1)
  }
  sum <- 0
  for ( k in 0:n ) sum <- sum + snsk(n, k)
  sum
}

## ----timeBellFunctions---------------------------------------------------
system.time(bell.using.rscala(16))
system.time(bell.using.R(16))

## ----arbitraryScalaCode--------------------------------------------------
s %~% '
  val a = new scala.util.Random()
  a.setSeed(1234)
  println(a.nextGaussian)
  val b = BigInt.probablePrime(16, a)
  val c = Array(b)
  c(0) = b.pow(4)
  c(0).intValue
'

## ----arbitraryScalaCodeWithoutOutput-------------------------------------
intpSettings(s, quiet=TRUE)
s %~% '
  val a = new scala.util.Random()
  a.setSeed(1234)
  println(a.nextGaussian)
  val b = BigInt.probablePrime(16, a)
  val c = Array(b)
  c(0) = b.pow(4)
  c(0).intValue
'

## ----getReference--------------------------------------------------------
s %.~% 'c(0).intValue'

## ----stringInterpolation-------------------------------------------------
class.name <- 'STAT 624'
s %~% '"@{tolower(class.name)}".reverse'

## ----gettingAndSetting---------------------------------------------------
normal.Mean0.Sd1 <- rnorm(10)
normal.Mean0.Sd1

intpSet(s, 'x', normal.Mean0.Sd1)
intpEval(s, 'val y = x.map(2 * _ + 1)')

normal.Mean1.Sd2 <- intpGet(s, 'y')
normal.Mean1.Sd2

## ----gettingAndSettingShorthand------------------------------------------
s$x <- normal.Mean0.Sd1
normal.Mean1.Sd2 <- s$y

## ----noMemoryManagementNeeded,results='hide'-----------------------------
e <- s$do('scala.util.Random')$new()
sapply(1:1000, function(i) e$nextGaussian())
f <- s$def('n: Int', 'Array.fill(n) { scala.util.Random.nextGaussian }')
g1 <- f(1000)

## ----resultAsReference,results='hide'------------------------------------
g2 <- f(1000, as.reference=TRUE)

## ----garbageCollection,results='hide'------------------------------------
rm(g2)
intpGC(s)

## ----callbacksVersion1---------------------------------------------------
myMean <- function(x) {
  cat('Here I am.\n')
  mean(x)
}

callRFunc <- s$def('functionName: String, x: Array[Double]', '
  R.xx = x
  R.evalD0(s"$functionName(xx)")
')

callRFunc('myMean', 1:100, quiet=FALSE)

## ----callbacksVersion2---------------------------------------------------
callRFunc <- s$def('f: RObject, x: RObject', '
  R.evalD0(s"$f($x)")
')

callRFunc(intpWrap(s, myMean), intpWrap(s, 1:100), quiet=FALSE)

## ----whereAreTheJars-----------------------------------------------------
rscala::rscalaJar()

## ----whereAreTheJarsSpecific---------------------------------------------
rscala::rscalaJar('2.10')
rscala::rscalaJar('2.11')

## ----scalaScript,engine="scala",engine.opts=paste0('-cp "',rscala::rscalaJar('2.11'),'"'),comment="//"----
# // Scala code
# val R = org.ddahl.rscala.callback.RClient()
# val side = R.evalS0("sample(c('heads', 'tails'), 1)")
# println(s"Your coin landed $side.")

## ----runtimeException, out.lines=10--------------------------------------
x <- s %~% '
  val n = 10
  if ( n != 20 ) throw new RuntimeException("n is not 20.")
'
x$"isInstanceOf[RuntimeException]"()
x$getMessage()

## ----exceptionStackTrace, out.lines=10-----------------------------------
x$printStackTrace(quiet=FALSE)

## ----exceptionMessage----------------------------------------------------
x <- s %~% 'val a = new ClassThatDoesNotExist()'
x$getMessage()

## ----compiletimeException------------------------------------------------
x <- s %~% 'R.eval("nonexistantFunctionInR()")'
x$getMessage()

## ----onLoad, eval=FALSE--------------------------------------------------
## .onLoad <- function(libname, pkgname) {
##   rscalaPackage(pkgname)
##   rscalaLoad()
## }

## ----mailR.rJava, eval=FALSE---------------------------------------------
## base_dir <- .jnew("java.io.File", normalizePath(getwd()))

## ----mailR.rscala, eval=FALSE--------------------------------------------
## base_dir <- E$s$do("java.io.File")$new(normalizePath(getwd()))

## ----fasterAfterFirstTime------------------------------------------------
system.time( s$do("sys")$props("user.name") )
system.time( s$do("sys")$props("user.name") )

## ----scalaScript2,engine="scala",engine.opts=paste0('-nowarn -cp "',rscala::rscalaJar('2.11'),'"'),comment="//"----
# // Scala code
# val a = List[String]("apples", "bananas")
# 
# var b = List.empty[String]
# b = "bananas" :: b
# b = "apples"  :: b
# 
# println(a == b)

## ----rscalaEquivalent----------------------------------------------------
a <- s$do('List')$apply('apples', 'bananas')

b <- s$do('List')$'empty[String]'()
b <- b$'::'('bananas')
b <- b$'::'('apples')

cat( a$'=='(b) )

## ----rJavaEquivalent-----------------------------------------------------
library('rJava')
.jinit()
.jaddClassPath(rscala::scalaInfo()$jars)

b <- .jnew('scala.collection.immutable.List$')$empty()
b <- b$'$colon$colon'('bananas')
b <- b$'$colon$colon'('apples')

b$equals(b)

## ----sleepFunction, eval=FALSE-------------------------------------------
## sleep <- function(secs) {
##   Sys.sleep(secs)
##   rnorm(1)
## }

## ----webappUsingR, eval=FALSE--------------------------------------------
## library("weatherData")
## library("ggplot2")
## theme_set(theme_gray(base_size=18))
## 
## .cache <- new.env()
## cache <- function(location, year) {
##   key <- paste0(location, "-", year)
##   if ( exists(key, envir=.cache) ) get(key, envir=.cache)
##   else {
##     d <- na.omit(getWeatherForYear(location, year))
## 
##     maxT <- d[which.max(d$Max_TemperatureF), c("Max_TemperatureF", "Date")]
##     minT <- d[which.min(d$Min_TemperatureF), c("Min_TemperatureF", "Date")]
## 
##     p <- ggplot(d, aes(x=Date)) + coord_cartesian(ylim = c(-10, 110))
##     p <- p + labs(x="", y=expression(paste("Temperature (", degree, "F)")))
##     p <- p + geom_line(aes(y=Max_TemperatureF))
##     p <- p + stat_smooth(se=FALSE, aes(y=Max_TemperatureF), method="loess", span=0.3)
##     p <- p + geom_line(aes(y=Min_TemperatureF))
##     p <- p + stat_smooth(se=FALSE, aes(y=Min_TemperatureF), method="loess", span=0.3)
##     p <- p + geom_ribbon(aes(ymin=Min_TemperatureF, ymax=Max_TemperatureF),
##                              fill = "tomato", alpha = 0.4)
## 
##     fn <- normalizePath(paste0(tempdir(), .Platform$file.sep, key, ".svg"))
##     svg(fn, width=6, height=4)
##     print(p)
##     dev.off()
## 
##     fmt <- "%B %e, %Y"
##     result <- list(filename=fn, minValue=minT[1, 1], minDate=format(minT[1, 2], fmt),
##                                 maxValue=maxT[1, 1], maxDate=format(maxT[1, 2], fmt))
##     assign(key, result, envir=.cache)
##     result
##   }
## }

