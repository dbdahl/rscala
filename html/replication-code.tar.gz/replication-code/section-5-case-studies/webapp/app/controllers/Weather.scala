package controllers

import java.io._
import java.util._
import models.TemperatureData
import play.api._
import play.api.mvc._

object Weather extends Controller {

  private val R = org.ddahl.rscala.callback.RClient()

  R.synchronized{ R eval """
    library(weatherData)
    library(ggplot2)
    theme_set(theme_gray(base_size=18))

    .cache <- new.env()
    cache <- function(location,year) {
      key <- paste0(location,"-",year)
      if ( exists(key,envir=.cache) ) get(key,envir=.cache)
      else {
        d <- na.omit(getWeatherForYear(location,year))

        maxT <- d[which.max(d$Max_TemperatureF), c("Max_TemperatureF", "Date")]
        minT <- d[which.min(d$Min_TemperatureF), c("Min_TemperatureF", "Date")]
        
        p <- ggplot(d, aes(x=Date)) + coord_cartesian(ylim = c(-10, 110))
        p <- p + labs(x="",y=expression(paste("Temperature (",degree,"F)")))
        p <- p + geom_line(aes(y=Max_TemperatureF))
        p <- p + stat_smooth(se=FALSE,aes(y=Max_TemperatureF),method="loess",span=0.3)
        p <- p + geom_line(aes(y=Min_TemperatureF))
        p <- p + stat_smooth(se=FALSE,aes(y=Min_TemperatureF),method="loess",span=0.3)
        p <- p + geom_ribbon(aes(ymin=Min_TemperatureF, ymax=Max_TemperatureF), fill = "tomato", alpha = 0.4)

        fn <- normalizePath(paste0(tempdir(),.Platform$file.sep,key,".svg"))
        svg(fn,width=6,height=4)
        print(p)
        dev.off()

        fmt <- "%B %e, %Y"
        result <- list(filename=fn, minValue=minT[1, 1], minDate=format(minT[1, 2], fmt),
                                    maxValue=maxT[1, 1], maxDate=format(maxT[1, 2], fmt))
        assign(key,result,envir=.cache)
        result
      }
    }
  """}

  private val errorTemperatureData = TemperatureData(null,null,"NA","NA","NA","NA")

  private def getTemperatureData(location: String, year: String) = {
    if ( location == null ) errorTemperatureData
    else try {
      val s1 = R.synchronized{R.evalS1(s"unlist(cache('$location','$year'))")}
      TemperatureData(location,year,s1(1),s1(2),s1(3),s1(4))
    } catch {
      case _: Throwable => errorTemperatureData
    }
  }

  private def validate(location: String, year: String): (String,String) = {
    if ( location.matches("\\w{3,4}") && year.matches("\\d{4}") ) (location.toUpperCase,year)
    else (null,null)
  }

  def index = Action { implicit request =>
    val previousYear = (Calendar.getInstance().get(Calendar.YEAR)-1).toString
    Redirect(routes.Weather.main("PVU",previousYear))
  }

  def redirect(location: String, year: String) = Action { implicit request =>
    Redirect(routes.Weather.main(location,year))
  }

  def main(location: String, year: String) = Action {
    val (loc,yr) = validate(location,year)
    val td = getTemperatureData(loc,yr)
    val tdView = if ( td.location == null ) TemperatureData(location.take(4).toUpperCase,year.take(4),"NA","NA","NA","NA")
    else td
    Ok(views.html.weather(tdView))
  }

  def plot(location: String, year: String, format: String) = {
    if ( format != "svg" ) Action { Ok("Invalid plot type.") }
    else {
      val (loc,yr) = validate(location,year)
      if ( loc == null ) Action { Ok("Invalid URL.") }
      else try {
        val file = new java.io.File(R.synchronized{R.evalS0(s"cache('$loc','$yr')[['filename']]")})
        val source = scala.io.Source.fromFile(file)(scala.io.Codec.UTF8)
        val byteArray = source.map(_.toByte).toArray
        source.close()
        Action { Ok(byteArray).as("image/svg+xml") }
      } catch {
        case _: Throwable => Action { Ok("No data.") }
      }
    }
  }

}

