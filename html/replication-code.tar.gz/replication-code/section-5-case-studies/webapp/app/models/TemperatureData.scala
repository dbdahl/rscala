package models

case class TemperatureData(location: String, year: String,
                           minValue: String, minDate: String,
                           maxValue: String, maxDate: String)


