# b0: Mean of the normal prior distribution for Beta0
# b1: Mean of the normal prior distribution for Beta1
# s0: Std. dev. of the normal prior distribution for Beta0
# s1: Std. dev. of the normal prior distribution for Beta1

b0 <- -1
s0 <- 1
b1 <- 1
s1 <- 1

# Simulated data

set.seed(2334523)
x <- seq(0,2,length=200)
n <- rep(100,length=length(x))
p <- 1/(1+exp(-(b0+b1*x)))
summary(p)
y <- rbinom(length(x),n,prob=p)

