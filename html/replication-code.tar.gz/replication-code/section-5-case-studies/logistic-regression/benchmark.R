source("sampler-rscala.R")
source("sampler-pureR.R")
source("sampler-C.R")

source(paste0("data-",dataName,".R"))

samplera <- makeSampler.rscala(x,y,n,b0,s0,b1,s1)
samplerb <- makeSampler.pureR (x,y,n,b0,s0,b1,s1)
samplerc <- makeSampler.C     (x,y,n,b0,s0,b1,s1)

library(microbenchmark)

results <- lapply(c(1,6,12),function(nCores) {
  microbenchmark(
  a=samplera(c(b0,b1),nDraws,nBurnin,nCores),
  b=samplerb(c(b0,b1),nDraws,nBurnin,nCores),
  c=samplerc(c(b0,b1),nDraws,nBurnin,nCores),
  times=nReps)
})

save(results, file=paste0("results-",dataName,".Rbin"))

