nDraws <- 1000000
nBurnin <- 1000
nReps <- 30

source("data-simulate.R")
source("sampler-pureR.R")

samplerb <- makeSampler.pureR (x,y,n,b0,s0,b1,s1)

nCores <- 1

Rprof()
samplerb(c(b0,b1),nDraws,nBurnin,nCores)
Rprof(NULL)

summaryRprof()

