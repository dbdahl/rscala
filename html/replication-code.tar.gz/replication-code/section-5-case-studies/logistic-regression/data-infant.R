# b0: Mean of the normal prior distribution for Beta0
# b1: Mean of the normal prior distribution for Beta1
# s0: Std. dev. of the normal prior distribution for Beta0
# s1: Std. dev. of the normal prior distribution for Beta1

b0 <- -15
s0 <- 5
b1 <- 1
s1 <- 1

# x: Gestational age of the infant (in weeks) at the time of birth
# y: Number of infants that were breast feeding at the time of release from hospital
# n: Total number of infants

x <- c(28,29,30,31,32,33)
y <- c( 2, 2, 7, 7,16,14)
n <- c( 6, 5, 9, 9,20,15)

