library(rscala)
intp <- scalaInterpreter("commons-math3-3.4.jar")
intpSettings(intp,quiet=TRUE)

makeSampler.rscala <- function(x,y,n,b0,s0,b1,s1) {
  intp$x <- x
  intp$y <- as.integer(y)
  intp$n <- as.integer(n)
  intpEval(intp,'
  import org.apache.commons.math3.distribution.{NormalDistribution,BinomialDistribution}
  import org.apache.commons.math3.util.FastMath.exp

  val rng = new org.apache.commons.math3.random.Well19937c()
  val priorB0 = new NormalDistribution(@{b0},@{s0})
  val priorB1 = new NormalDistribution(@{b1},@{s1})

  def logTargetDensity(state: Array[Double]) = {
    var sum = priorB0.logDensity(state(0)) + priorB1.logDensity(state(1))
    var i = 0
    while ( i < x.length ) {
      val p = 1 / ( 1 + exp(-(state(0)+state(1)*x(i))) )
      val binomial = new BinomialDistribution(null,n(i),p)
      sum += binomial.logProbability(y(i))
      i += 1
    }
    sum
  }')
  intp$def('state: Array[Double], nIterations: Int, thinning: Int, nChains: Int','
    val initialLogDensityState = logTargetDensity(state)
    val nDrawsPerChain = nIterations/nChains/thinning
    val rngs = Array.fill(nChains)(new org.apache.commons.math3.random.Well19937c(rng.nextLong))
    rngs.par.map(r => {
      val current = state.clone
      var logDensityState = initialLogDensityState
      val draws = new Array[Array[Double]](nDrawsPerChain)
      val proposal = current.clone
      Array.fill(nDrawsPerChain) {
        for ( i <- 0 until thinning ) {
          if ( i % 2 == 0 ) {
            proposal(0) = current(0) + 2*(r.nextDouble()-0.5)
            proposal(1) = current(1)
          } else {
            proposal(0) = current(0)
            proposal(1) = current(1) + 0.1*(r.nextDouble()-0.5)
          }
          val logDensityProposal = logTargetDensity(proposal)
          val logMHRatio = logDensityProposal - logDensityState
          if ( r.nextDouble < exp(logMHRatio) ) {
            current(0) = proposal(0)
            current(1) = proposal(1)
            logDensityState = logDensityProposal
          }
        }
        current.clone
      }
    }).toArray.flatten
  ')
}

