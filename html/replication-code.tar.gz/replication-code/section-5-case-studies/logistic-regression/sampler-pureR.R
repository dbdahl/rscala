library(parallel)

makeSampler.pureR <- function(x,y,n,b0,s0,b1,s1) {
  logTargetDensity <- function(state) {
    sum <- dnorm(state[1],b0,s0,log=TRUE) + dnorm(state[2],b1,s1,log=TRUE)
    p <- 1 / ( 1 + exp(-(state[1]+state[2]*x)) )
    sum + sum(dbinom(y,n,p,log=TRUE))
  }
  function(state, nIterations, thinning, nChains) {
    initialLogDensityState <- logTargetDensity(state)
    nDrawsPerChain <- nIterations/nChains/thinning
    oneChain <- function(k) {
      current <- state
      logDensityState <- initialLogDensityState
      draws <- matrix(NA,nrow=nDrawsPerChain,ncol=2)
      for ( j in 1:nDrawsPerChain ) {
        for ( i in 1:thinning ) {
          proposal <- current
          if ( i %% 2 == 0 ) proposal[1] <- current[1] + runif(1,-1,1)
          else proposal[2] <- current[2] + runif(1,-0.05,0.05)
          logDensityProposal <- logTargetDensity(proposal)
          logMHRatio <- logDensityProposal - logDensityState
          if ( runif(1) < exp(logMHRatio) ) {
            current <- proposal
            logDensityState <- logDensityProposal
          }
        }
        draws[j,] <- current
      }
      draws
    }
    do.call(rbind,mclapply(1:nChains,oneChain,mc.cores=nChains))
  }
}

