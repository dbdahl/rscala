writeLines('
  #include <math.h>
  #include <R.h>
  #include <Rmath.h>

  double logTargetDensity(double* state, int nObs, double* x, int *y, int *n,
                          double b0, double s0, double b1, double s1) {
    double sum = dnorm(state[0],b0,s0,1) + dnorm(state[1],b1,s1,1);
    int i = 0;
    while ( i < nObs ) {
      double p = 1 / ( 1 + exp(-(state[0]+state[1]*x[i])) );
      sum += dbinom(y[i],n[i],p,1);
      i++;
    }
    return sum;
  }

  void sample(double* state, int *nDrawsPerChain, int *thinning,
              int* nObs, double* x, int *y, int *n,
              double* b0, double* s0, double* b1, double* s1,
              double* draws) {
    GetRNGstate();
    double* current = state;
    double logDensityState = logTargetDensity(current,*nObs,x,y,n,*b0,*s0,*b1,*s1);
    double* proposal = malloc(2*sizeof(double));
    for ( int j=0; j<*nDrawsPerChain; j++ ) {
      for( int i=0; i<*thinning; i++ ) {
        if ( i % 2 == 0 ) {
          proposal[0] = current[0] + runif(-1.0,1.0);
          proposal[1] = current[1];
        } else {
          proposal[0] = current[0];
          proposal[1] = current[1] + runif(-0.05,0.05);
        }
        double logDensityProposal = logTargetDensity(proposal,*nObs,x,y,n,*b0,*s0,*b1,*s1);
        double logMHRatio = logDensityProposal - logDensityState;
        if ( runif(0.0,1.0) < exp(logMHRatio) ) {
          current[0] = proposal[0];
          current[1] = proposal[1];
          logDensityState = logDensityProposal;
        }
      }
      draws[2*j]   = current[0];
      draws[2*j+1] = current[1];
    }
    PutRNGstate();
  }
',con="C.c")

system("R CMD SHLIB C.c")
dyn.load("C.so")
file.remove(c("C.c","C.so","C.o"))

library(parallel)

makeSampler.C <- function(x,y,n,b0,s0,b1,s1) {
  function(state, nIterations, thinning, nChains) {
    nDrawsPerChain <- nIterations/nChains/thinning
    oneChain <- function(k) {
      out <- .C("sample",
                state=as.double(state),
                nIterations=as.integer(nDrawsPerChain),
                thinning=as.integer(thinning),
                nObs=as.integer(length(x)),
                x=as.double(x),
                y=as.integer(y),
                n=as.integer(n),
                b0=as.double(b0),
                s0=as.double(s0),
                b1=as.double(b1),
                s1=as.double(s1),
                samples=double(2*nDrawsPerChain))
      matrix(out$samples,ncol=2,byrow=TRUE)
    }
    do.call(rbind,mclapply(1:nChains,oneChain,mc.cores=nChains))
  }
}

