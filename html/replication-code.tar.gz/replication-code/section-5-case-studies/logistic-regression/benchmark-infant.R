dataName <- "infant"

nDraws <- 1000000
nBurnin <- 1000
nReps <- 30

source("benchmark.R")

