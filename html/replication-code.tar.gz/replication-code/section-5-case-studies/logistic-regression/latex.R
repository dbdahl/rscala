library(microbenchmark)
library(xtable)

extract <- function(filename) {
  load(filename)
  rows <- c(1,3,2)
  x <- matrix(NA,nrow=length(results),ncol=length(rows))
  dimnames(x) <- list(c("Scala","C","R"),c("1 core","6 cores","12 cores"))
  for ( i in 1:ncol(x) ) x[,i] <- summary(results[[i]],unit="s")[rows,"mean"]
  y <- matrix(NA,nrow=nrow(x),ncol=2*ncol(x))
  dimnames(y) <- list(dimnames(x)[[1]],rep(dimnames(x)[[2]],each=2))
  for ( i in 1:ncol(x) ) {
    y[,2*i-1] <- x[,i]
    y[,2*i]   <- x[,i]/x[1,i]
  }
  y
}

xtable(extract("results-infant.Rbin"))
xtable(extract("results-simulate.Rbin"))

