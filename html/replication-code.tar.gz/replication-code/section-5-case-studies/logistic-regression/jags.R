library(R2jags)

writeLines('
  model  {
    for (i in 1:6) {
      y[i] ~ dbin(p[i],n[i])
      logit(p[i]) <- b0 + b1*x[i]
    }
    b0 ~ dnorm(-15,1/5^2)
    b1 ~ dnorm(1,1)
  }
',con='jags.mdl')

x <- c(28,29,30,31,32,33)
y <- c( 2, 2, 7, 7,16,14)
n <- c( 6, 5, 9, 9,20,15)

data.jags <- c('x','y','n')
parms <- c('b0','b1')

jags.sim <- jags(data=data.jags,inits=NULL,parameters.to.save=parms,
     model.file='jags.mdl',n.iter=110000,n.burnin=10000,n.chains=1,
     n.thin=1)

file.remove("jags.mdl")

apply(jags.sim$BUGSoutput$sims.matrix,2,mean)
library(coda)
effectiveSize(jags.sim$BUGSoutput$sims.matrix)

plot(jags.sim$BUGSoutput$sims.matrix[,1:2])

