library(microbenchmark)
library(xtable)

load("results.Rbin")

options(width=120)

computeRatios <- function(results) {
  r <- list()
  for ( i in 1:length(results) ) {
    r[[i]] <- summary(results[[i]],unit="s")
    r[[i]]$ratio <- r[[i]]$mean/r[[i]]$mean[grep("sleep\\(seconds\\)",as.character(r[[i]]$expr))]
    r[[i]]$sampleSize <- as.numeric(names(results)[i])
  }
  names(r) <- names(results)
  r
}

drop <- function(results) {
  r <- list()
  for ( i in 1:length(results) ) {
    r[[i]] <- results[[i]][,c("expr","mean","ratio","sampleSize")] 
  }
  names(r) <- names(results)
  r 
}

makeTable <- function(results,dropColumns=c()) {
  resultsA <- drop(computeRatios(results))
  table <- matrix(NA,nrow=nrow(resultsA[[1]]),ncol=2*length(resultsA))
  dimnames(table) <- list(rep("",nrow(table)),rep("",ncol(table)))
  for ( i in 1:length(resultsA) ) {
    table[,2*(i-1)+1] <- sprintf("%12.4f",resultsA[[i]]$mean)
    table[,2*(i-1)+2] <- sprintf("%7.3f",resultsA[[i]]$ratio)
    colnames(table)[2*(i-1)+1] <- prettyNum(resultsA[[i]]$sampleSize[1],big.mark=",")
    colnames(table)[2*(i-1)+2] <- prettyNum(resultsA[[i]]$sampleSize[1],big.mark=",")
  }
  if ( length(dropColumns) > 0 ) table <- table[,-dropColumns]
  rownames(table) <- resultsA[[1]]$expr
  xtable(table)
}

makeTable(results)

