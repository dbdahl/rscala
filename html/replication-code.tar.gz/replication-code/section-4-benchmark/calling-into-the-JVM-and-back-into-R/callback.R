### function

sleep <- function(secs) {
  Sys.sleep(secs)
  rnorm(1)
}


### Rcpp

library(Rcpp)
cppFunction('SEXP callbackRcpp(NumericVector x, Function func) {
  return func(x);
}')

callback.Rcpp <- function(x,func) {
  callbackRcpp(x,func)
}
callback.Rcpp(0.1,sleep)


### rJava

writeLines('
  import org.rosuda.JRI.Rengine;

  public class Callback {

    public static double callback(Rengine engine, double secs, String functionName) {
      engine.assign("secs",new double[]{secs});
      return engine.eval(functionName+"(secs)").asDouble();
    }

  }
',con="Callback.java")
classpath <- list.files(system.file("jri",package="rJava"),pattern=".*.jar",full.names=TRUE)
system2("javac",c("-cp",paste(classpath,collapse=.Platform$path.sep),"Callback.java"))

options(java.parameters = "-Xmx4G")
library(rJava)
.jinit()
engine <- .jengine(start=TRUE)
.jaddClassPath(".")

callback.rJava <- function(x,function.name) {
  .jcall("Callback","D","callback",engine,x,function.name)
}
callback.rJava(0.1,"sleep")


### rscala

library(rscala)
s <- scalaInterpreter()
sleep.wrapped <- intpWrap(s,sleep)

callback.rscala <- s$def('x: Array[Double], func: RObject','
  R.xx = x
  R.evalD1(s"$func(xx)")
')
callback.rscala(0.1,sleep.wrapped)


### microbenchmark

library(microbenchmark)

times <- 10
secs <- c(1.0, 0.01, 0.0)
names(secs) <- secs

results <- lapply(secs,function(seconds) {
  intpGC(s)
  microbenchmark(
    sleep(seconds),
    callback.Rcpp(seconds,sleep),
    callback.rJava(seconds,"sleep"),
    callback.rscala(seconds,sleep.wrapped),
    times=50,
    unit="s"
  )
})
results


save(results,file="results.Rbin")
sessionInfo()

