import org.ddahl.rscala.java.RClient;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.REXPMismatchException;
import java.io.*;

public class NormalQQPlot {
  
  private RClient rClient;
  private RConnection rConnection;

  public NormalQQPlot(RClient rClient, RConnection rConnection)
  throws REngineException {
    this.rClient = rClient;
    this.rConnection = rConnection;
    if ( rConnection != null )
      rConnection.eval("setwd('"+System.getProperty("user.dir")+"')");
  }

  private String snippet = 
      "filename <- tempfile(tmpdir='plots',fileext='.pdf')\n" +
      "pdf(filename)\n" +
      "qqnorm(samples)\n" +
      "qqline(samples)\n" +
      "dev.off()";

  public String create(double[] x, boolean useRserve)
  throws REngineException, REXPMismatchException {
    if ( useRserve ) {
      rConnection.assign("samples",x);
      rConnection.eval(snippet);
      return rConnection.get("filename",null,true).asString();
    } else {
      rClient.set("samples",x);
      rClient.eval(snippet,true);
      return rClient.getS0("filename");
    }
  }

  public static double[] sample(java.util.Random rng, double[] x) {
    for ( int i=0; i<x.length; i++ ) x[i] = rng.nextGaussian();
    return x;
  }

  public static void main(String[] args) throws Exception {
    java.util.Random rng = new java.util.Random();
    double[] x = new double[100];
    if ( args.length == 0 ) {
      RClient rClient = new RClient();
      NormalQQPlot normalQQPlot = new NormalQQPlot(rClient,null);
      System.out.println(normalQQPlot.create(sample(rng,x),false));
    } else if ( args[0].equals("rserve") || args[0].equals("rscala") ) {
      boolean doRSERVE = args[0].equals("rserve");
      int nPlots = Integer.parseInt(args[1]);
      RClient rClient = null;
      RConnection rConnection = null;
      if ( doRSERVE ) {
        rConnection = new RConnection();
      } else {
        rClient = new RClient();
      }
      NormalQQPlot normalQQPlot = new NormalQQPlot(rClient,rConnection);
      for ( int j=0; j<nPlots; j++ ) {
        sample(rng,x);
        System.out.println(normalQQPlot.create(x,doRSERVE));
      }
      if ( doRSERVE ) rConnection.serverShutdown();
    } else if ( args[0].equals("rscript") ) {
      int nPlots = Integer.parseInt(args[1]);
      Runtime runtime = Runtime.getRuntime();
      String[] cmd = { "./normalQQPlot", "" };
      for ( int j=0; j<nPlots; j++ ) {
        sample(rng,x);
        File file = File.createTempFile("rscript-", ".bin", new File("plots"));
        DataOutputStream out = new DataOutputStream(new FileOutputStream(file));
        out.writeInt(x.length);
        for ( int i=0; i<x.length; i++ ) out.writeDouble(x[i]);
        out.close();
        cmd[1] = file.getPath();
        Process p = runtime.exec(cmd);
        BufferedReader is = new BufferedReader(
                            new InputStreamReader(p.getInputStream()));
        p.waitFor();
        System.out.println(is.readLine());
      }
    } else {
      System.out.println("To run demo, supply no arguments.");
      System.out.println("To benchmark, supply either 'rscala' or 'system'"+
                         " and then the number of plots.");
    }
  }

}

