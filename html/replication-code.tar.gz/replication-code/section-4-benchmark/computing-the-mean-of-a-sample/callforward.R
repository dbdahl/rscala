if ( file.exists("results.Rbin") ) stop("Results file already exists.")


### Standard R

standardR1 <- function(n) {
  mean(runif(n))
}
standardR1(1)

standardR2 <- function(n) {
  sum <- 0.0
  for ( i in 1:n ) sum <- sum + runif(1)
  sum/n
}
standardR2(1)


### Rcpp

library(Rcpp)

cppFunction('double mRcpp(int n) {
  double sum = 0.0;
  for ( int i=0; i < n; i++ ) {
    sum += R::runif(0,1);
  }
  return sum/n;
}')
mRcpp(1)


### rJava

options(java.parameters = "-Xmx4G")
library(rJava)
.jinit()

rJava1 <- function(n) {
  rng.rJava <- .jnew("java.util.Random")
  sum <- 0.0
  for ( i in 1:n ) sum <- sum + .jcall(rng.rJava,"D","nextDouble")
  sum/n
}
rJava1(1)

rJava2 <- function(n) {
  rng.rJava <- .jnew("java.util.Random")
  sum <- 0.0
  for ( i in 1:n ) sum <- sum + rng.rJava$nextDouble()
  sum/n
}
rJava2(1)

writeLines('
  public class Benchmark {

    public static double mean(int nSamples) {
      java.util.Random rng = new java.util.Random();
      double sum = 0.0;
      for ( int i=0; i<nSamples; i++ ) {
        sum += rng.nextDouble();
      }
      return sum/nSamples;
    }

  }
',con="Benchmark.java")
system2("javac","Benchmark.java")
.jaddClassPath(".")

rJava3 <- function(n) {
  .jcall("Benchmark","D","mean",as.integer(n))
}
rJava3(1)


### rscala

library(rscala)
s <- scalaInterpreter(".",java.heap.maximum="4G")

rscala1 <- function(n) {
  rng.rscala <- s$do("java.util.Random")$new()
  sum <- 0.0
  for ( i in 1:n ) sum <- sum + rng.rscala$nextDouble()
  sum/n
}
rscala1(1)

rscala2 <- function(n) {
  rng.rscala <- s$do("java.util.Random")$new()
  sum <- 0.0
  func <- rng.rscala$nextDouble(evaluate=FALSE)
  for ( i in 1:n ) sum <- sum + func()
  sum/n
}
rscala2(1)

rscala3 <- s$def('n: Int','
  val rng = new java.util.Random()
  Array.fill(n)(rng.nextDouble).sum/n
')
rscala3(1)

rscala4 <- s$def('n: Int','
  val rng = new java.util.Random()
  var sum = 0.0
  var i = 0
  while ( i < n ) {
    sum += rng.nextDouble
    i += 1
  }
  sum/n
')
rscala4(1)

rscala5 <- s$do("Benchmark")$mean(as.integer(0),evaluate=FALSE)
rscala5(1)


### microbenchmark

library(microbenchmark)
times <- 50

nSamples <- 10^c(0,1,2,3,4)
names(nSamples) <- nSamples

results1 <- lapply(nSamples,function(n) {
  intpGC(s)
  microbenchmark(
    mRcpp(n),
    standardR2(n),
    rJava1(n),
    rJava2(n),
    rscala1(n),
    rscala2(n),
    times=times,
    unit="ms"
  )
})
results1


nSamples <- 10^c(0,2,4,6,8)
names(nSamples) <- nSamples

results2 <- lapply(nSamples,function(n) {
  intpGC(s)
  microbenchmark(
    mRcpp(n),
    standardR1(n),
    rJava3(n),
    rscala3(n),
    rscala4(n),
    rscala5(n),
    times=times,
    unit="ms"
  )
})
results2


save(results1,results2,file="results.Rbin")
sessionInfo()

