.onLoad <- function(libname, pkgname) {
  rscalaPackage(pkgname)
  rscalaLoad()
}
